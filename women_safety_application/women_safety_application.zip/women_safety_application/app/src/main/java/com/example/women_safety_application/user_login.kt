package com.example.women_safety_application

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import kotlinx.android.synthetic.main.user_login.*
import java.util.jar.Manifest

class user_login : AppCompatActivity() {
    var count = 0
    var PERMISSION_ID = 1000
    lateinit var use_location: FusedLocationProviderClient
    lateinit var location_req: LocationRequest

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.user_login)

        use_location = LocationServices.getFusedLocationProviderClient(this)
        location.setOnClickListener {

            count++

            if (count > 2) {
                Toast.makeText(this, "One", Toast.LENGTH_SHORT).show()
            }
        }

        policecall.setOnClickListener {

            val phone = "+918016447610"
            val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phone, null))
            startActivity(intent)
        }
        emergen.setOnClickListener {
            var intee1 = Intent(this, emergencycall::class.java)
            startActivity(intee1)
        }

        family_massage.setOnClickListener {
            /* val uu = Intent(Intent.ACTION_SEND) /// Action send is the ID ,ex:- gmail , without this you cannot able to send any single message...
            uu.setType("text/plain") /// setType is giving you the type of your message..
            uu.putExtra(Intent.EXTRA_SUBJECT,"kool") /// EXTRA_SUJECT is behave like gmail...
            val gg = "I am in danger ,,Please to here to help me.."  /// it store the sending thing ..hare sending thing is link of java-T point..
            uu.putExtra(Intent.EXTRA_TEXT,gg) //// this permission is allows you to write any message in the permission..
            startActivity(Intent.createChooser(uu,"Share By Subhashish"))/// createCoooser is in-built method which is basically used to display the sending platform...like - whatsapp, telegram, skype,   and show it in a dialog box ,,,using title we give some title dialog box..
            */
            /*val intee = Intent(this,testing::class.java)
            startActivity(intee)*/
        }


    }
    /// here wee create a function that will check the user permission..
}