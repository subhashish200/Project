package com.example.women_safety_application

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.police_login_oo.*

class police_login_oo : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.police_login_oo)

       /* var name = police_name_login.text.toString()
        var id12 = police_idd.text.toString()*/



        police_log.setOnClickListener {
            var name = police_name_login.text.toString()
            var id12 = police_idd.text.toString()

            if (name.isEmpty()){
                Toast.makeText(this,"Enter your registered name :",Toast.LENGTH_SHORT).show()
            }
            else if (id12.isEmpty()){
                Toast.makeText(this,"Enter your registered ID :",Toast.LENGTH_SHORT).show()
            }

            else{

                val database_calling: DatabaseReference = FirebaseDatabase.getInstance("https://womensafety-e81d4-default-rtdb.firebaseio.com/").getReference("WomenSafety")
                //var check_user : Query = database_calling.orderByChild("name1").equalTo(name)
               // var check_user2 : Query = database_calling.orderByChild("police_id").equalTo(id12)

                database_calling.addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(p0: DataSnapshot) {
                       /* if (p0.exists()){
                            var gg = p0.child(name).child("name1").getValue(String.javaClass)
                            if (gg != null) {
                                if (gg.equals(id12)){
                                    Toast.makeText(applicationContext,"Successfully registerd:",Toast.LENGTH_SHORT).show()
                                    val intee = Intent(baseContext,women_information_list::class.java)
                                    startActivity(intee)
                                }
                            }

                        }
                        else{
                            Toast.makeText(applicationContext," Not Successfully registerd:",Toast.LENGTH_SHORT).show()
                        }*/
                        if(p0.hasChild(name)){
                            var get_id = p0.child(name).child("police_id").getValue(String.javaClass)
                            Log.d("Sujata",""+get_id)


                            //if (get_id != null) {
                                if(get_id?.equals(id12) == true){
                                    Toast.makeText(applicationContext,"Successfully registerd:",Toast.LENGTH_SHORT).show()
                                } else{
                                    Toast.makeText(applicationContext," wrong password:",Toast.LENGTH_SHORT).show()
                                }
                            //}
                        }

                       /* if (p0.exists()){
                            var gg = p0.child(name).child("name1").getValue(String.javaClass)
                            if (gg != null) {
                                if (gg.equals(id12)){
                                    Toast.makeText(applicationContext,"Successfully registerd:",Toast.LENGTH_SHORT).show()
                                    val intee = Intent(baseContext,women_information_list::class.java)
                                    startActivity(intee)
                                }
                            }

                        }*/



                        else{
                            Toast.makeText(applicationContext,"Unsuccessful:",Toast.LENGTH_SHORT).show()
                        }

                    }

                    override fun onCancelled(p0: DatabaseError) {
                        TODO("Not yet implemented")
                    }


                })
            }

/*
            if(name.isEmpty()){
                Toast.makeText(this,"Enter your registered name:",Toast.LENGTH_SHORT).show()
            }
            else if (id12.isEmpty()){
                Toast.makeText(this,"Enter your registered id:",Toast.LENGTH_SHORT).show()
            }
            else{
                val database_calling: DatabaseReference = FirebaseDatabase.getInstance("https://womensafety-e81d4-default-rtdb.firebaseio.com/").getReference("WomenSafety")
                var check_user : Query = database_calling.orderByChild("name1").equalTo(name)
                var check_user2 : Query = database_calling.orderByChild("police_id").equalTo(id12)

                check_user2.addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(p0: DataSnapshot) {
                        if (p0.exists()){
                            var gg = p0.child(name).child("name1").getValue(String.javaClass)
                            if (gg != null) {
                                if (gg.equals(id12)){
                                    Toast.makeText(applicationContext,"Successfully registerd:",Toast.LENGTH_SHORT).show()
                                }
                            }

                        }
                    }

                    override fun onCancelled(p0: DatabaseError) {
                        TODO("Not yet implemented")
                    }


                })
            }*/
        }

    }


}