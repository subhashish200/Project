package com.example.women_safety_application

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class women_information_list : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.women_information_list)
    }
}