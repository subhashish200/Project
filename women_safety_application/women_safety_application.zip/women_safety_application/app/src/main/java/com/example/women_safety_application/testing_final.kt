package com.example.women_safety_application

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Looper
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.*
import kotlinx.android.synthetic.main.police_registration_form.*
import kotlinx.android.synthetic.main.testing.*
import kotlinx.android.synthetic.main.user_login.*
import java.util.*

class testing_final : AppCompatActivity()  {
    var count = 0
    var PERMISSION_ID = 1000
    lateinit var use_location : FusedLocationProviderClient
    lateinit var location_req : LocationRequest

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.user_login)




        use_location = LocationServices.getFusedLocationProviderClient(this)
        location.setOnClickListener {

            // Search for restaurants nearby
            val gmmIntentUri = Uri.parse("geo:0,0?q=police station")
            val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
            mapIntent.setPackage("com.google.android.apps.maps")
            startActivity(mapIntent)

// Search for restaurants in San Francisco
            /*val gmmIntentUri =
                Uri.parse("geo:37.7749,-122.4194?q=restaurants")
            val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
            mapIntent.setPackage("com.google.android.apps.maps")
            startActivity(mapIntent)*/

            /*// Create a Uri from an intent string. Use the result to create an Intent.
            val gmmIntentUri = Uri.parse("google.streetview:cbll=46.414382,10.013988")

// Create an Intent from gmmIntentUri. Set the action to ACTION_VIEW
            val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
// Make the Intent explicit by setting the Google Maps package
            mapIntent.setPackage("com.google.android.apps.maps")

// Attempt to start an activity that can handle the Intent
            startActivity(mapIntent)*/

            /*val mapUri = Uri.parse("geo:41.414116,-73.303566,?q=" + Uri.encode(address.toString()))
            val mapIntent = Intent(Intent.ACTION_VIEW, mapUri)
            mapIntent.setPackage("com.google.android.apps.maps")
            startActivity(mapIntent)*/

            /*count++

            if(count>2){
                Toast.makeText(this, "One", Toast.LENGTH_SHORT).show()
                val mapUri = Uri.parse("geo:41.414116,-73.303566,?q=" + Uri.encode(address.toString()))
                val mapIntent = Intent(Intent.ACTION_VIEW, mapUri)
                mapIntent.setPackage("com.google.android.apps.maps")
                startActivity(mapIntent)
            }*/
        }

        policecall.setOnClickListener {

            val phone = "+918016447610"
            val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phone, null))
            startActivity(intent)
        }
        emergen.setOnClickListener {
            var intee1 = Intent(this, emergencycall::class.java)
            startActivity(intee1)
        }

        family_massage.setOnClickListener {
           /*val uu = Intent(Intent.ACTION_SEND) /// Action send is the ID ,ex:- gmail , without this you cannot able to send any single message...
            uu.setType("text/plain") /// setType is giving you the type of your message..
            uu.putExtra(Intent.EXTRA_SUBJECT,"kool") /// EXTRA_SUJECT is behave like gmail...
            val gg = "I am in danger ,,Please to here to help me.."  /// it store the sending thing ..hare sending thing is link of java-T point..
            uu.putExtra(Intent.EXTRA_TEXT,gg) //// this permission is allows you to write any message in the permission..
            startActivity(Intent.createChooser(uu,"Share By Subhashish"))/// createCoooser is in-built method which is basically used to display the sending platform...like - whatsapp, telegram, skype,   and show it in a dialog box ,,,using title we give some title dialog box..
            */
            /*val intee = Intent(this,testing::class.java)
            startActivity(intee)*/

            /*babu.setOnClickListener {


            }*/
            get_last_location()

       }


    }
    /// here wee create a function that will check the user permission..

    fun check_location(): Boolean {
        if(ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            )== PackageManager.PERMISSION_GRANTED ||
            ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            )== PackageManager.PERMISSION_GRANTED){
            return true
        }
        return false

    }
    fun request_permission(){
        ActivityCompat.requestPermissions(
            this, arrayOf(
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            ), PERMISSION_ID
        )
    }

    fun location_enable():Boolean{
        var location : LocationManager = getSystemService(Context.LOCATION_SERVICE)as LocationManager
        return location.isProviderEnabled(LocationManager.GPS_PROVIDER) || location.isProviderEnabled(
            LocationManager.NETWORK_PROVIDER
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)


        if(requestCode == PERMISSION_ID){
            if(grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Log.d("check the permission", "subhan")
            }
        }
        /// we will crete the function that will allow us to get the last location...



    }
    private fun get_last_location(){
        /// first we check permission..
        if(check_location()){
            /// now the we check the location is enable or disable..
            if(location_enable()){
                /// actually get the current location...
                if (ActivityCompat.checkSelfPermission(
                        this,
                        android.Manifest.permission.ACCESS_FINE_LOCATION
                    ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                        this,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return
                }
                use_location.lastLocation.addOnCompleteListener {
                    var locati = it.result
                    if (locati==null){
                        get_new_location()
                    }
                    else{
                       /* tgf.text = "Your Current Codinator are: \n Lat:"+locati.latitude +
                                "Longi:"+locati.longitude + "\nYour City : " + getCityName(locati.latitude,locati.longitude)+"Country Name:"+getCountryName(locati.latitude,locati.longitude)*/
                        val uu = Intent(Intent.ACTION_SEND) /// Action send is the ID ,ex:- gmail , without this you cannot able to send any single message...
                        uu.setType("text/plain") /// setType is giving you the type of your message..
                        uu.putExtra(Intent.EXTRA_SUBJECT, "kool") /// EXTRA_SUJECT is behave like gmail...
                        val gg = "Your Current Codinator are: \n Lat:"+locati.latitude +
                                "Longi:"+locati.longitude + "\nYour City : " + getCityName(
                            locati.latitude,
                            locati.longitude
                        )+"Country Name:"+getCountryName(locati.latitude, locati.longitude) /// it store the sending thing ..hare sending thing is link of java-T point..
                        uu.putExtra(Intent.EXTRA_TEXT, gg) //// this permission is allows you to write any message in the permission..
                        startActivity(Intent.createChooser(uu, "Share By Subhashish"))/// createCoooser is in-built method which is basically used to display the sending platform...like - whatsapp, telegram, skype,   and show it in a dialog box ,,,using title we give some title dialog box..
                    }
                }
            }
            else{
                Toast.makeText(this, "Please enable your location service", Toast.LENGTH_SHORT).show()
            }
        }
        else{
            request_permission()
        }
    }

    fun get_new_location(){
        location_req = LocationRequest()
        location_req.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        location_req.interval = 0
        location_req.fastestInterval = 0
        location_req.numUpdates = 2
        if (ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return
        }
        use_location!!.requestLocationUpdates(
            location_req, locationCallBack, Looper.myLooper()
        )
    }
    val locationCallBack = object: LocationCallback(){
        override fun onLocationResult(p0: LocationResult) {
            var lastLocation : Location = p0.lastLocation
            /*tgf.text = "Your Current Codinator are: \n Lat:"+lastLocation.latitude + "Longi:"+lastLocation.longitude + "\nYour City : " +
                    "" + getCityName(lastLocation.latitude,lastLocation.longitude)+"Country Name:"+getCountryName(lastLocation.latitude,lastLocation.longitude)*/
            val uu = Intent(Intent.ACTION_SEND) /// Action send is the ID ,ex:- gmail , without this you cannot able to send any single message...
            uu.setType("text/plain") /// setType is giving you the type of your message..
            uu.putExtra(Intent.EXTRA_SUBJECT, "kool") /// EXTRA_SUJECT is behave like gmail...
            val gg = "Your Current Codinator are: \n Lat:"+lastLocation.latitude + "Longi:"+lastLocation.longitude + "\nYour City : " +
                    "" + getCityName(lastLocation.latitude, lastLocation.longitude)+"Country Name:"+getCountryName(
                lastLocation.latitude,
                lastLocation.longitude
            )  /// it store the sending thing ..hare sending thing is link of java-T point..
            uu.putExtra(Intent.EXTRA_TEXT, gg) //// this permission is allows you to write any message in the permission..
            startActivity(Intent.createChooser(uu, "Share By Subhashish"))/// createCoooser is in-built method which is basically used to display the sending platform...like - whatsapp, telegram, skype,   and show it in a dialog box ,,,using title we give some title dialog box..

        }
    }

    fun getCityName(lat: Double, long: Double):String{
        var cityName = " "
        var gCoder = Geocoder(this, Locale.getDefault())
        var address_name : MutableList<Address>? = gCoder.getFromLocation(lat, long, 1)

        if (address_name != null) {
            cityName = address_name.get(0).locality
        }








        return cityName
    }
    fun getCountryName(lat: Double, long: Double):String{
        var countryName = " "
        var gCoder = Geocoder(this, Locale.getDefault())
        var address_name : MutableList<Address>? = gCoder.getFromLocation(lat, long, 1)

        if (address_name != null) {
            countryName = address_name.get(0).countryName
        }

        return countryName
    }

}