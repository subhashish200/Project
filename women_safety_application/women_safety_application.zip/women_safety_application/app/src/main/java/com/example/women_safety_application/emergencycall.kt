package com.example.women_safety_application

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.emergencycall.*
import kotlinx.android.synthetic.main.user_login.*
import java.lang.Appendable

class emergencycall:AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.emergencycall)

        li1.setOnClickListener {

            val phone = "+918016447610"
            val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phone, null))
            startActivity(intent)
        }
        li2.setOnClickListener {

            val phone = "+918016447610"
            val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phone, null))
            startActivity(intent)
        }
        li3.setOnClickListener {

            val phone = "+918016447610"
            val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phone, null))
            startActivity(intent)
        }
        li4.setOnClickListener {

            val phone = "+918016447610"
            val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phone, null))
            startActivity(intent)
        }

    }

}