package com.example.women_safety_application

class database_model_class_for_registration(
    var idd:String?,
    var name1:String?,
    var station: String?,

    val address: String?,

    val pin_code: Int?,

    val police_id: String,

    val phone_number:String?,
   val rank: String?

)