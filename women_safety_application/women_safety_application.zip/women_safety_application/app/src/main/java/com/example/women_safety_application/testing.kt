package com.example.women_safety_application

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.*
import kotlinx.android.synthetic.main.testing.*
import java.util.*

class testing : AppCompatActivity() {
    var PERMISSION_ID = 1000
    lateinit var use_location : FusedLocationProviderClient
    lateinit var location_req : LocationRequest
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.testing)
        use_location = LocationServices.getFusedLocationProviderClient(this)

        babu.setOnClickListener {
            get_last_location()

        }
    }

    fun check_location(): Boolean {
        if(ActivityCompat.checkSelfPermission(this,android.Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_GRANTED ||
            ActivityCompat.checkSelfPermission(this,android.Manifest.permission.ACCESS_COARSE_LOCATION)== PackageManager.PERMISSION_GRANTED){
            return true
        }
        return false

    }
    fun request_permission(){
        ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION,android.Manifest.permission.ACCESS_COARSE_LOCATION),PERMISSION_ID)
    }

    fun location_enable():Boolean{
        var location : LocationManager = getSystemService(Context.LOCATION_SERVICE)as LocationManager
        return location.isProviderEnabled(LocationManager.GPS_PROVIDER) || location.isProviderEnabled(
            LocationManager.NETWORK_PROVIDER)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)


        if(requestCode == PERMISSION_ID){
            if(grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Log.d("check the permission","subhan")
            }
        }
        /// we will crete the function that will allow us to get the last location...



    }
    private fun get_last_location(){
        /// first we check permission..
        if(check_location()){
            /// now the we check the location is enable or disable..
            if(location_enable()){
                /// actually get the current location...
                if (ActivityCompat.checkSelfPermission(
                        this,
                        android.Manifest.permission.ACCESS_FINE_LOCATION
                    ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                        this,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return
                }
                use_location.lastLocation.addOnCompleteListener {
                    var locati = it.result
                    if (locati==null){
                        get_new_location()
                    }
                    else{
                        tgf.text = "Your Current Codinator are: \n Lat:"+locati.latitude +
                                "Longi:"+locati.longitude + "\nYour City : " + getCityName(locati.latitude,locati.longitude)+"Country Name:"+getCountryName(locati.latitude,locati.longitude)
                    }
                }
            }
            else{
                Toast.makeText(this,"Please enable your location service", Toast.LENGTH_SHORT).show()
            }
        }
        else{
            request_permission()
        }
    }

    fun get_new_location(){
        location_req = LocationRequest()
        location_req.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        location_req.interval = 0
        location_req.fastestInterval = 0
        location_req.numUpdates = 2
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return
        }
        use_location!!.requestLocationUpdates(
           location_req,locationCallBack,Looper.myLooper()
       )
    }
    val locationCallBack = object:LocationCallback(){
        override fun onLocationResult(p0: LocationResult) {
            var lastLocation : Location = p0.lastLocation
            tgf.text = "Your Current Codinator are: \n Lat:"+lastLocation.latitude + "Longi:"+lastLocation.longitude + "\nYour City : " +
                    "" + getCityName(lastLocation.latitude,lastLocation.longitude)+"Country Name:"+getCountryName(lastLocation.latitude,lastLocation.longitude)
        }
    }

    fun getCityName(lat:Double,long: Double):String{
        var cityName = " "
        var gCoder = Geocoder(this, Locale.getDefault())
        var address_name : MutableList<Address>? = gCoder.getFromLocation(lat,long,1)

        if (address_name != null) {
            cityName = address_name.get(0).locality
        }








        return cityName
    }
    fun getCountryName(lat:Double,long: Double):String{
        var countryName = " "
        var gCoder = Geocoder(this, Locale.getDefault())
        var address_name : MutableList<Address>? = gCoder.getFromLocation(lat,long,1)

        if (address_name != null) {
            countryName = address_name.get(0).countryName
        }

        return countryName
    }

}