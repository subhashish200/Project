package com.example.women_safety_application

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.police_registration_form.*
import java.util.regex.Pattern

class police_registration_form : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.police_registration_form)

        login_kk.setOnClickListener {
            val intee = Intent(this,police_login_oo::class.java)
            startActivity(intee)
        }

        /// mobile validation..........
       ph_number.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (mobile_vaidation(ph_number.text.toString())){
                    register.isEnabled = true
                }
                else{
                    register.isEnabled = false
                }
            }

            override fun afterTextChanged(s: Editable?) {

            }

        })

        register.setOnClickListener {
            if (name.text.trim().isEmpty()){
                Toast.makeText(this,"Please enter your name:",Toast.LENGTH_SHORT).show()
            }
            else if (station.text.trim().isEmpty()){
                Toast.makeText(this,"Please enter your station name:",Toast.LENGTH_SHORT).show()
            }
            else if (address.text.trim().isEmpty()){
                Toast.makeText(this,"Please enter your address name:",Toast.LENGTH_SHORT).show()
            }
            else if (pin.text.trim().isEmpty()){
                Toast.makeText(this,"Please enter your pin number:",Toast.LENGTH_SHORT).show()
            }
            else if (police_id1.text.trim().isEmpty()){
                Toast.makeText(this,"Please enter your Police id:",Toast.LENGTH_SHORT).show()
            }
           else if (ph_number.text.trim().isEmpty()){
                Toast.makeText(this,"Please enter your phone number:",Toast.LENGTH_SHORT).show()
            }
            else if (rank.text.trim().isEmpty()){
                Toast.makeText(this,"Please enter your rank:",Toast.LENGTH_SHORT).show()
            }
           else if(ph_number.length() !=10){
                Toast.makeText(this,"Please enter 10 digit number:",Toast.LENGTH_SHORT).show()
            }
            else{

                val a = name.text.toString()
                val b = station.text.toString()

                val c = address.text.toString()

                val d = pin.text.toString().toInt()

               val e = police_id1.text.toString()


               val f = ph_number.text.toString()
                val g = rank.text.toString()


                /// calling the fire base database
                val database_calling = FirebaseDatabase.getInstance("https://womensafety-e81d4-default-rtdb.firebaseio.com/").getReference("WomenSafety")
                val position_change = database_calling.push().key /// push method is basically used to change the position of counter..
                /// key is represent your counter position..
                val mod= database_model_class_for_registration(position_change,a,b,c,d,e,f,g)
                database_calling.child(position_change.toString()).setValue(mod)
                Toast.makeText(this,"Successfully Registered:",Toast.LENGTH_SHORT).show()
            }
            /*Toast.makeText(this,"Please enter your rank:",Toast.LENGTH_SHORT).show()*/

        }





    }
    fun mobile_vaidation(test:String?):Boolean{
        var p = Pattern.compile("[6-9][0-9]{9}")
        var m = p.matcher(test)/// matcher is inbuilt
        return m.matches()
    }
}