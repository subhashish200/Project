package com.example.c_application
//basic_model_class
class  operator_model_class (
  /*  val name_basic : String,

    val img_basic:Int*/
    val name_operator : String,

    val img_operator:Int


)