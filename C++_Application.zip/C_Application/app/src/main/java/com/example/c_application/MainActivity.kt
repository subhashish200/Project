package com.example.c_application

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.navigation.NavigationView
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val lis = mutableListOf<model_class>()
        lis.add(model_class(R.drawable.b, "Basic C++"))
        lis.add(model_class(R.drawable.b, "Variable & Data type"))
        lis.add(model_class(R.drawable.b, "Operator"))
        lis.add(model_class(R.drawable.b, "If Else"))
        lis.add(model_class(R.drawable.b, "Switch Case"))
        lis.add(model_class(R.drawable.b, "Loops"))
        lis.add(model_class(R.drawable.p, "Pattern"))
        lis.add(model_class(R.drawable.b, "Array"))
        lis.add(model_class(R.drawable.b, "String"))
        lis.add(model_class(R.drawable.b, "Function"))
        lis.add(model_class(R.drawable.s, "Structure"))
        lis.add(model_class(R.drawable.b, "Union"))
        lis.add(model_class(R.drawable.b, "Class & Object"))
        lis.add(model_class(R.drawable.b, "Constructor & Destructor"))

        cus_list.adapter = main_adapter_class(this, R.layout.main_xml_for_image_text, lis)
        /////  for final display purpose in this current activity
        // we basically use this line... setOnItemClickListener

        cus_list.setOnItemClickListener { parent, view, position, id ->
            if (position == 0) {
                var intee1 = Intent(this, basic::class.java)

                startActivity(intee1)

            }
            if (position == 5) {
                var intee1 = Intent(this, loop_main::class.java)

                startActivity(intee1)

            }
            if (position == 6) {
                var intee1 = Intent(this, pattern_main::class.java)

                startActivity(intee1)

            }
            if (position == 8) {
                var intee1 = Intent(this, string_main::class.java)

                startActivity(intee1)

            }
            if (position == 7) {
                var intee1 = Intent(this, array_main::class.java)

                startActivity(intee1)

            }
            if (position == 4) {
                var intee1 = Intent(this, switchcase_main::class.java)

                startActivity(intee1)

            }
            if (position == 9) {
                var ino= Intent(this, function_main::class.java)

                startActivity(ino)

            }
            if (position == 10) {
                var intee1 = Intent(this, structure_main::class.java)

                startActivity(intee1)

            }
            if (position == 11) {
                var intee1 = Intent(this, union_main::class.java)

                startActivity(intee1)

            }
            if (position == 3) {
                var intee1 = Intent(this, ifelse_main::class.java)

                startActivity(intee1)

            }
            if (position == 1) {
                var intee1 = Intent(this, variabledatatype_main::class.java)

                startActivity(intee1)

            }
            if (position == 2) {
                var intee1 = Intent(this, operator_main::class.java)

                startActivity(intee1)

            }
            if (position == 13) {
                var intee1 = Intent(this, constructure_main::class.java)

                startActivity(intee1)

            }
            if (position == 12) {
                var intee1 = Intent(this, classobject_main::class.java)

                startActivity(intee1)

            }
        }

        nav_view.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.navigation_share -> {
                    /*var inn1 = Intent(this,demo_practice::class.java)
                    startActivity(inn1)*/
                    Toast.makeText(this, "subhashish", Toast.LENGTH_SHORT).show()
                }


                R.id.navigation_review -> {

                    Toast.makeText(this, "subhashish", Toast.LENGTH_SHORT).show()
                }
                R.id.navigation_google -> {

                    val ii = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/"))
                    startActivity(ii)
                }
                R.id.navigation_youtube -> {

                    val ii = Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com/"))
                    startActivity(ii)
                }


            }
            true

        }
    }


        /// Navigation Drawer:=>


}