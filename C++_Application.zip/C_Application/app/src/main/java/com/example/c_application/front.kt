package com.example.c_application

import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity

class front: AppCompatActivity() {
    val timeming = 5000L
    // adding music with flash screen..
    lateinit var musi: MediaPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.front)

        musi = MediaPlayer.create(applicationContext,R.raw.music) // calling the MediaPlayer and assign to musi object and
        // also set the music using applicationcontext in built class..
        musi.start() // start playing music...

        Handler().postDelayed({
            intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
            finish()
        },timeming)

    }
}