package com.example.c_application

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ListView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction

class union_fragment : Fragment(){
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        //return super.onCreateView(inflater, container, savedInstanceState)
        val a = inflater.inflate(R.layout.union_list, container, false)
        val lis1 = mutableListOf<union_model_class>()
        /*// backpressed..
        val call_back = object : OnBackPressedCallback(true){
            override fun handleOnBackPressed() {

            }
        }*/

        lis1.add(union_model_class("1. Union example 1", R.drawable.arrow))
        lis1.add(union_model_class("2. Union example 2", R.drawable.arrow))
        lis1.add(union_model_class("3. Union example 3.", R.drawable.arrow))
        lis1.add(union_model_class("4. Union example 4 .", R.drawable.arrow))


        val babu = a.findViewById<Button>(R.id.unionvideo)

        babu.setOnClickListener {
            val ii = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/"))
            startActivity(ii)
        }


        val my_listid = a.findViewById<ListView>(R.id.union_lis)

        my_listid.adapter = context?.let { union_adapter(it, R.layout.union_allitem_showing, lis1) }

        my_listid.setOnItemClickListener { parent, view, position, id ->


            if (position == 0) {

                val first_item1_loop = first_item_union()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_union,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 1) {

                val first_item1_loop = second_item_union()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_union,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 2) {

                val first_item1_loop = third_item_union()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_union,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 3) {

                val first_item1_loop = forth_item_union()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_union,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }







        }





        return a
    }
}