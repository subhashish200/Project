package com.example.c_application

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ListView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction

class ifelse_fragment : Fragment(){
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        //return super.onCreateView(inflater, container, savedInstanceState)
        val a = inflater.inflate(R.layout.ifelse_list, container, false)
        val lis1 = mutableListOf<ifelse_model_class>()
        /*// backpressed..
        val call_back = object : OnBackPressedCallback(true){
            override fun handleOnBackPressed() {

            }
        }*/

        lis1.add(ifelse_model_class("Program to print positive number entered by the user.", R.drawable.arrow))
        lis1.add(ifelse_model_class("Program to check whether an integer is positive or negative .", R.drawable.arrow))
        lis1.add(ifelse_model_class("Program to check whether an integer is positive, negative or zero.", R.drawable.arrow))
        lis1.add(ifelse_model_class("Program to find if an integer is even or odd or neither (0)", R.drawable.arrow))
        lis1.add(ifelse_model_class("Program to Check Whether a character is Vowel or Consonant.", R.drawable.arrow))
        lis1.add(ifelse_model_class("Check if a year is leap year or not.", R.drawable.arrow))

        val babu = a.findViewById<Button>(R.id.ifelsevideo)

        babu.setOnClickListener {
            val ii = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/"))
            startActivity(ii)
        }


        val my_listid = a.findViewById<ListView>(R.id.ifelse_lis)

        my_listid.adapter = context?.let { ifelse_adapter(it, R.layout.ifelse_allitem_showing, lis1) }

        my_listid.setOnItemClickListener { parent, view, position, id ->


            if (position == 0) {

                val first_item1_loop = first_item_ifelse1()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_ifelse,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if(position==1){
                val second_item1 = second_item_ifelse()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_ifelse,second_item1)
                tran.addToBackStack(null)
                tran.commit()
            }
            if(position==2){
                val third_item1 = third_item_ifelse()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_ifelse,third_item1)
                tran.addToBackStack(null)
                tran.commit()
            }
            if(position==3){
                val fourth_item1 = forth_item_ifelse()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_ifelse,fourth_item1)
                tran.addToBackStack(null)
                tran.commit()
            }
            if(position==4){
                val fifth_item1 = fifth_item_ifelse()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_ifelse,fifth_item1)
                tran.addToBackStack(null)
                tran.commit()
            }
            if(position==5){
                val sixth_item1 = sixth_item_ifelse()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_ifelse,sixth_item1)
                tran.addToBackStack(null)
                tran.commit()
            }







        }





        return a
    }
}