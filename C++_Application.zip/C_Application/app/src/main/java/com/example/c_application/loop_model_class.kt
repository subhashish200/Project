package com.example.c_application
//basic_model_class
class  loop_model_class (
  /*  val name_basic : String,

    val img_basic:Int*/
    val name_loop : String,

    val img_loop:Int


)