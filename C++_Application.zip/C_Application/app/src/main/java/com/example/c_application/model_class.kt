package com.example.c_application

class model_class  (

    val img:Int,
    val name: String
    )