package com.example.c_application

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ListView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction

class pattern_fragment : Fragment(){
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        //return super.onCreateView(inflater, container, savedInstanceState)
        val a = inflater.inflate(R.layout.pattern_list, container, false)
        val lis1 = mutableListOf<pattern_model_class>()
        /*// backpressed..
        val call_back = object : OnBackPressedCallback(true){
            override fun handleOnBackPressed() {

            }
        }*/

        lis1.add(pattern_model_class("Pattern Example-1", R.drawable.arrow))
        lis1.add(pattern_model_class("Pattern Example-2", R.drawable.arrow))
        lis1.add(pattern_model_class("Pattern Example-3", R.drawable.arrow))
        lis1.add(pattern_model_class("Pattern Example-4", R.drawable.arrow))
        lis1.add(pattern_model_class("Pattern Example-5", R.drawable.arrow))
        lis1.add(pattern_model_class("Pattern Example-6", R.drawable.arrow))
        lis1.add(pattern_model_class("Pattern Example-7", R.drawable.arrow))
        lis1.add(pattern_model_class("Pattern Example-8", R.drawable.arrow))
        lis1.add(pattern_model_class("Pattern Example-9", R.drawable.arrow))
        lis1.add(pattern_model_class("Pattern Example-10", R.drawable.arrow))


        val babu = a.findViewById<Button>(R.id.patternvideo)

        babu.setOnClickListener {
            val ii = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/"))
            startActivity(ii)
        }
        val my_listid = a.findViewById<ListView>(R.id.pattern_lis)

        my_listid.adapter = context?.let { pattern_adapter(it, R.layout.pattern_allitem_showing, lis1) }

        my_listid.setOnItemClickListener { parent, view, position, id ->


            if (position == 0) {

                val first_item1_loop = first_item_pattern()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_pattern,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 1) {

                val first_item1_loop = second_item_pattern()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_pattern,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 2) {

                val first_item1_loop = third_item_pattern()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_pattern,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 3) {

                val first_item1_loop = forth_item_pattern()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_pattern,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 4) {

                val first_item1_loop = fifth_item_pattern()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_pattern,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 5) {

                val first_item1_loop = sixth_item_pattern()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_pattern,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position ==6) {

                val first_item1_loop = seventh_item_pattern()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_pattern,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 7) {

                val first_item1_loop = eightth_item_pattern()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_pattern,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 8) {

                val first_item1_loop = nineth_item_pattern()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_pattern,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 9) {

                val first_item1_loop = tenth_item_pattern()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_pattern,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }






        }





        return a
    }
}