package com.example.c_application
//basic_model_class
class  structure_model_class (
  /*  val name_basic : String,

    val img_basic:Int*/
    val name_structure : String,

    val img_structure:Int


)