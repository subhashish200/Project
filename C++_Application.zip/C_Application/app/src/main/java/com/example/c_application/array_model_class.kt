package com.example.c_application
//basic_model_class
class  array_model_class (
  /*  val name_basic : String,

    val img_basic:Int*/
    val name_array : String,

    val img_array:Int


)