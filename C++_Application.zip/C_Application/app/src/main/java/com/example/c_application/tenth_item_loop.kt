package com.example.c_application

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
/*import kotlinx.android.synthetic.main.all_items.*
import kotlinx.android.synthetic.main.another_activity.**/
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader

class tenth_item_loop : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val a = inflater.inflate(R.layout.loop_question_answer_showing, container, false)
        var string: String? = ""
        val stringBuilder = StringBuilder()
        var num : InputStream = requireContext().assets.open("sumofdigit.txt")
        val reader = BufferedReader(InputStreamReader(num))
        while (true) {
            try {
                if (reader.readLine().also { string = it } == null) break
            } catch (e: IOException) {
                e.printStackTrace()
            }
            stringBuilder.append(string).append("\n")
            val bb = a.findViewById<TextView>(R.id.code_loop)
            bb.text = stringBuilder

        }
        num.close()
/*        Toast.makeText(context, stringBuilder.toString(),
            Toast.LENGTH_LONG).show()*/
        return a
    }

}