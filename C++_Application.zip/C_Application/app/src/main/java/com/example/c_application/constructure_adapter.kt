package com.example.c_application
//basic_adapter
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView

class constructure_adapter(val con : Context, var pos : Int, var item_data_type : List<constructure_model_class> ) : ArrayAdapter<constructure_model_class>(con,pos,item_data_type) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View { /// getView is helip you to view the custom list item....

        val layout_inflat:LayoutInflater = LayoutInflater.from(con)  /*layoutInflator is basically filter  the data using context...   it basically marge the xml files and
        and the final marging xml file is filtered by the layoutInfalter and put the final xml file in a single xml file in a proper manner.. */

        val vie: View = layout_inflat.inflate(pos,null)  /// this line is basically give the final view of the marging xml file which is created by LayoutoutInflater
        // using View in_built class  and store it in the vie variable.... null is used for giving the blank list..on which we  will put the element/list item...
        val image_vit = vie.findViewById<ImageView>(R.id.img1_constructure)  ////storing the id of ImageView...
        val text_vie = vie.findViewById<TextView>(R.id.constructure_text_1)  /// storing the id of the text view...
        var model:constructure_model_class = item_data_type[position] ///  it provides the connection between custom_adapter class and model_class...with proper position...
        image_vit.setImageResource(model.img_constructure) /// using to set the image the in 'image_vit' id   using 'model' variable...
        text_vie.text = model.name_constructure/// using to set the name  the in 'text_vie' id   using 'model' variable...
        return vie   // finally returning the custom_lit class which is main class...
    }
}