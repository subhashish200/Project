package com.example.c_application

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ListView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import kotlinx.android.synthetic.main.array_list.*

class array_fragment : Fragment(){

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        //return super.onCreateView(inflater, container, savedInstanceState)
        val a = inflater.inflate(R.layout.array_list, container, false)
        val lis1 = mutableListOf<array_model_class>()
        /*// backpressed..
        val call_back = object : OnBackPressedCallback(true){
            override fun handleOnBackPressed() {

            }
        }*/

        lis1.add(array_model_class("1. Write a C++ program to find the largest element of a given array of integers.", R.drawable.arrow))
        lis1.add(array_model_class("2. Write a C++ program to find the largest three elements in an array.\n", R.drawable.arrow))
        lis1.add(array_model_class("3. Write a C++ program to find second largest element in a given array of integers. ", R.drawable.arrow))
        lis1.add(array_model_class("4. Write a C++ program to find k largest elements in a given array of integers.", R.drawable.arrow))
        lis1.add(array_model_class("5. Write a C++ program to find the second smallest elements in a given array of integers. ", R.drawable.arrow))
        lis1.add(array_model_class("6. Write a C++ program to find all elements in array of integers which have at-least two greater elements. \n", R.drawable.arrow))
        lis1.add(array_model_class("7. Write a C++ program to find the most occurring element in an array of integers.", R.drawable.arrow))
        lis1.add(array_model_class("8. Write a C++ program to find the next greater element of every element of a given array of integers.\n" +
                "   Ignore those elements which have no greater element.", R.drawable.arrow))
        lis1.add(array_model_class("9. Write a C++ program to sort a given unsorted array of integers, in wave form.", R.drawable.arrow))
        lis1.add(array_model_class("10. Write a C++ program to find the smallest element missing in a sorted array.", R.drawable.arrow))





        val babu = a.findViewById<Button>(R.id.arrayvideo)

        babu.setOnClickListener {
            val ii = Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com/"))
            startActivity(ii)
        }
        // var pp = (Button) findViewById(R.id.start12);



        val my_listid = a.findViewById<ListView>(R.id.array_lis)

        my_listid.adapter = context?.let { array_adapter(it, R.layout.array_allitem_showing, lis1) }



        my_listid.setOnItemClickListener { parent, view, position, id ->


            if (position == 0) {

                val first_item1_loop = first_item_array()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_array,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 1) {

                val first_item1_loop = second_item_array()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_array,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 2) {

                val first_item1_loop = third_item_array()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_array,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 3) {

                val first_item1_loop = forth_item_array()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_array,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 4) {

                val first_item1_loop = fifth_item_array()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_array,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 5) {

                val first_item1_loop = sixth_item_array()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_array,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 6) {

                val first_item1_loop = seventh_item_array()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_array,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 7) {

                val first_item1_loop = eightth_item_array()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_array,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 8) {

                val first_item1_loop = nineth_item_array()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_array,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 9) {

                val first_item1_loop = tenth_item_array()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_array,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }







        }





        return a
    }
}