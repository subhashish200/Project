package com.example.c_application

class string_model_class(
    val name_string : String,

    val img_string:Int

)