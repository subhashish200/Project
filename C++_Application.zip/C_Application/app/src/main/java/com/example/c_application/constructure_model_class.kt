package com.example.c_application
//basic_model_class
class  constructure_model_class (
  /*  val name_basic : String,

    val img_basic:Int*/
    val name_constructure : String,

    val img_constructure:Int


)