package com.example.c_application

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ListView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction

class loop_fragment : Fragment(){
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        //return super.onCreateView(inflater, container, savedInstanceState)
        val a = inflater.inflate(R.layout.loop_list, container, false)
        val lis1 = mutableListOf<loop_model_class>()
        /*// backpressed..
        val call_back = object : OnBackPressedCallback(true){
            override fun handleOnBackPressed() {

            }
        }*/

        lis1.add(loop_model_class("Write a program in C++ to find the first 10 natural numbers.", R.drawable.arrow))
        lis1.add(loop_model_class("Write a program in C++ to find the sum of first 10 natural numbers.", R.drawable.arrow))
        lis1.add(loop_model_class("Write a program in C++ to display n terms of natural number and their sum.", R.drawable.arrow))
        lis1.add(loop_model_class(" Write a program in C++ to find the perfect numbers between 1 and 500.", R.drawable.arrow))
        lis1.add(loop_model_class(" Write a program in C++ to check whether a number is prime or not.", R.drawable.arrow))
        lis1.add(loop_model_class("Write a program in C++ to find prime number within a range.", R.drawable.arrow))
        lis1.add(loop_model_class("Write a program in C++ to find the factorial of a number.", R.drawable.arrow))
        lis1.add(loop_model_class("Write a program in C++ to find the last prime number occur before the entered number.", R.drawable.arrow))
        lis1.add(loop_model_class("Write a program in C++ to find the Greatest Common Divisor (GCD) of two numbers.", R.drawable.arrow))
        lis1.add(loop_model_class("Write a program in C++ to find the sum of digits of a given number.", R.drawable.arrow))


        val babu = a.findViewById<Button>(R.id.loopvideo)

        babu.setOnClickListener {
            val ii = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/"))
            startActivity(ii)
        }
        val my_listid = a.findViewById<ListView>(R.id.loop_lis)

        my_listid.adapter = context?.let { loop_adapter(it, R.layout.loop_allitem_showing, lis1) }

        my_listid.setOnItemClickListener { parent, view, position, id ->


            if (position == 0) {

                val first_item1_loop = first_item_loop()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_loop,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if(position==1){
                val second_item1 = second_item_loop()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_loop,second_item1)
                tran.addToBackStack(null)
                tran.commit()
            }
            if(position==2){
                val third_item1 = third_item_loop()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_loop,third_item1)
                tran.addToBackStack(null)
                tran.commit()
            }
            if(position==3){
                val fourth_item1 = forth_item_loop()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_loop,fourth_item1)
                tran.addToBackStack(null)
                tran.commit()
            }
            if(position==4){
                val fifth_item1 = fifth_item_loop()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_loop,fifth_item1)
                tran.addToBackStack(null)
                tran.commit()
            }
            if(position==5){
                val sixth_item1 = sixth_item_loop()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_loop,sixth_item1)
                tran.addToBackStack(null)
                tran.commit()
            }
            if(position==6){
                val sixth_item1 = seventh_item_loop()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_loop,sixth_item1)
                tran.addToBackStack(null)
                tran.commit()
            }
            if(position==7){
                val sixth_item1 = eighth_item_loop()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_loop,sixth_item1)
                tran.addToBackStack(null)
                tran.commit()
            }
            if(position==8){
                val sixth_item1 = nineth_item_loop()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_loop,sixth_item1)
                tran.addToBackStack(null)
                tran.commit()
            }
            if(position==9){
                val sixth_item1 = tenth_item_loop()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_loop,sixth_item1)
                tran.addToBackStack(null)
                tran.commit()
            }







        }





        return a
    }
}