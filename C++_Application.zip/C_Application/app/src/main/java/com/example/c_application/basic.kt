package com.example.c_application

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.FragmentManager
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.basic_replacing.*

class basic: AppCompatActivity (){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.basic_replacing)

        val fragment_activity2 = basic_fragment()
        val fr_manager: FragmentManager = supportFragmentManager

        // replace fragment xml file into activity xml file
        fr_manager.beginTransaction().add(R.id.frame,fragment_activity2).commit()

        val action_bar = supportActionBar
        action_bar!!.title = "Basic C++ Program:"
        action_bar.setDisplayHomeAsUpEnabled(true)








    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}