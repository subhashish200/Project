package com.example.c_application
//basic_model_class
class  union_model_class (
  /*  val name_basic : String,

    val img_basic:Int*/
    val name_union : String,

    val img_union:Int


)