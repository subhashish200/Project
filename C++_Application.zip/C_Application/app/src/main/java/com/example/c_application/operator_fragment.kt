package com.example.c_application

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ListView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction

class operator_fragment : Fragment(){
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        //return super.onCreateView(inflater, container, savedInstanceState)
        val a = inflater.inflate(R.layout.operator_list, container, false)
        val lis1 = mutableListOf<operator_model_class>()
        /*// backpressed..
        val call_back = object : OnBackPressedCallback(true){
            override fun handleOnBackPressed() {

            }
        }*/

        lis1.add(operator_model_class("1. Arithmetic Operators .", R.drawable.arrow))
        lis1.add(operator_model_class("2. Increment and Decrement Operators.", R.drawable.arrow))
        lis1.add(operator_model_class("3.  Assignment Operators.", R.drawable.arrow))
        lis1.add(operator_model_class("4. Relational Operators.", R.drawable.arrow))
        lis1.add(operator_model_class("5.  Logical Operators.", R.drawable.arrow))


        val babu = a.findViewById<Button>(R.id.operatorvideo)

        babu.setOnClickListener {
            val ii = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/"))
            startActivity(ii)
        }

        val my_listid = a.findViewById<ListView>(R.id.operator_lis)

        my_listid.adapter = context?.let { operator_adapter(it, R.layout.operator_allitem_showing, lis1) }

        my_listid.setOnItemClickListener { parent, view, position, id ->


            if (position == 0) {

                val first_item1_loop = first_item_operator()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_operator,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 1) {

                val first_item1_loop = second_item_operator()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_operator,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 2) {

                val first_item1_loop = third_item_operator()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_operator,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 3) {

                val first_item1_loop = forth_item_operator()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_operator,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if (position == 4) {

                val first_item1_loop = logical_item_operator()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_operator,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }





        }





        return a
    }
}