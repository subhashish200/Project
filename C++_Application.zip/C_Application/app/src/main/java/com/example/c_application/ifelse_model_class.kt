package com.example.c_application
//basic_model_class
class  ifelse_model_class (
  /*  val name_basic : String,

    val img_basic:Int*/
    val name_ifelse : String,

    val img_ifelse:Int


)