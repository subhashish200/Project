package com.example.c_application


import android.os.Bundle
import androidx.fragment.app.FragmentManager
import androidx.appcompat.app.AppCompatActivity

class pattern_main : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pattern_replacing)


        val fragment_activity3 = pattern_fragment()
        val fr_manager1: FragmentManager = supportFragmentManager

        // replace fragment xml file into activity xml file
        //fr_manager.beginTransaction().add(R.id.frame_loop,fragment_activity2).commit()
        fr_manager1.beginTransaction().add(R.id.frame_pattern,fragment_activity3).commit()

        val action_bar = supportActionBar
        action_bar!!.title = "C++ Program Pattern Program:"
        action_bar.setDisplayHomeAsUpEnabled(true)

    }
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

}