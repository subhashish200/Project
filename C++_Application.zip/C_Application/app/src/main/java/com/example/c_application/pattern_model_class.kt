package com.example.c_application

class pattern_model_class (
    val name_pattern : String,

    val img_pattern:Int

    )