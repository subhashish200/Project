package com.example.c_application

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ListView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction

class constructure_fragment : Fragment(){
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        //return super.onCreateView(inflater, container, savedInstanceState)
        val a = inflater.inflate(R.layout.constructure_list, container, false)
        val lis1 = mutableListOf<constructure_model_class>()
        /*// backpressed..
        val call_back = object : OnBackPressedCallback(true){
            override fun handleOnBackPressed() {

            }
        }*/

        lis1.add(constructure_model_class("Write a program in C++ to print a welcome text in a separate line", R.drawable.arrow))
        lis1.add(constructure_model_class("Write a program in C++ to print the sum of two numbers.", R.drawable.arrow))
        lis1.add(constructure_model_class("Write a program in C++ to find Size of fundamental data types", R.drawable.arrow))
        lis1.add(constructure_model_class("Write a program in C++ to print the sum of two numbers using variables.", R.drawable.arrow))
        lis1.add(constructure_model_class("Write a program in C++ to check the upper and lower limits of integer.", R.drawable.arrow))
        lis1.add(constructure_model_class("Write a program in C++ to check whether the primitive values crossing the limits or not. ", R.drawable.arrow))


        val my_listid = a.findViewById<ListView>(R.id.constructure_lis)

        my_listid.adapter = context?.let { constructure_adapter(it, R.layout.constructure_allitem_showing, lis1) }

        my_listid.setOnItemClickListener { parent, view, position, id ->


            if (position == 0) {

                val first_item1_loop = first_item_loop()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_constructure,first_item1_loop)
                tran.addToBackStack(null)

                tran.commit()

            }
            if(position==1){
                val second_item1 = second_item()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_constructure,second_item1).isAddToBackStackAllowed
                tran.commit()
            }
            if(position==2){
                val third_item1 = third_item()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_constructure,third_item1).isAddToBackStackAllowed
                tran.commit()
            }
            if(position==3){
                val fourth_item1 = fourth_item()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_constructure,fourth_item1).isAddToBackStackAllowed
                tran.commit()
            }
            if(position==4){
                val fifth_item1 = fifth_item()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_constructure,fifth_item1).isAddToBackStackAllowed
                tran.commit()
            }
            if(position==5){
                val sixth_item1 = sixth_item()
                val tran : FragmentTransaction = requireFragmentManager().beginTransaction()
                tran.replace(R.id.frame_constructure,sixth_item1).isAddToBackStackAllowed
                tran.commit()
            }







        }





        return a
    }
}