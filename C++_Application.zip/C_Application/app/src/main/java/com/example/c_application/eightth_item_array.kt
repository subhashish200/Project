package com.example.c_application

/*import kotlinx.android.synthetic.main.all_items.*
import kotlinx.android.synthetic.main.another_activity.**/

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader


class eightth_item_array : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val a = inflater.inflate(R.layout.array_question_answer_showing, container, false)
        var string: String? = ""
        val stringBuilder = StringBuilder()
        var num : InputStream = requireContext().assets.open("nextgreater8.txt")
        val reader = BufferedReader(InputStreamReader(num))



        while (true) {
            try {
                if (reader.readLine().also { string = it } == null) break
            } catch (e: IOException) {
                e.printStackTrace()
            }
            stringBuilder.append(string).append("\n")
            val bb = a.findViewById<TextView>(R.id.code_array)
            bb.text = stringBuilder

        }
        num.close()






        //////////// Copy text...............
        val bb = a.findViewById<TextView>(R.id.code_array)
        val bob = a.findViewById<Button>(R.id.copy_array)
        val share_loop = a.findViewById<Button>(R.id.share_array)
        bob.setOnClickListener {
            //copy2clipboard(code_loop.text.toString())
            //Toast.makeText(activity,"adsa",Toast.LENGTH_SHORT).show()

            val clipboard = getActivity()?.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("copy text", bb.text.toString())
            //val clip: ClipData = ClipData.newPlainText("diuh",text)
            //clipboard.primaryClip= clip
            clipboard?.setPrimaryClip(clip)
        }
        share_loop.setOnClickListener {
            shareIt(bb.text.toString())
        }
        return a

    }

    private fun shareIt(msg:String) {
        val intent = Intent()
        intent.action = Intent.ACTION_SEND
        intent.putExtra(Intent.EXTRA_SUBJECT, "Android Studio Pro")
        intent.putExtra(
            Intent.EXTRA_TEXT,
            "$msg  https://play.google.com/store/apps/details?id=com.tutorial.personal.androidstudiopro "
        )
        intent.type = "text/plain"
        startActivity(intent)
    }
    }